

const URL:string = 'https://gateway.pipeworx.io/spacex/v4/launches';
export async function recibeCohetes<Cohete>():Promise<Cohete[]>{
    return fetch(URL).then((response) =>{
        if(!response.ok) throw new Error(`Error en la peticion: ${response.status}`)
        return response.json();    
    }).then((data) =>{
        const respuesta:Cohete[] = data as Cohete[];
        console.log(respuesta);
        return respuesta;
    })
}
