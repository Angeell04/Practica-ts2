import './style.css';
import { recibeCohetes } from './peticion_cohete';
import type { Cohete } from './cohete-interface';

document.body.innerHTML = `
<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <title>Page Title</title>
    <link rel='stylesheet' href='main.css'>
</head>
<body>
  <main>
    <h1>Listado de cohetes</h1>
    <h3>Ejercicios</h3>
    <input id="busca-cohete" type="text" placeholder="nombre Cohete">
    <label for="filtro-estado">Filtrar por estado:</label>
    <select id="filtro-estado" name="estado">
      <option value="todos">Todos</option>
      <option value="exitoso">Exitosos</option>
      <option value="fallido">Fallidos</option>
      <option value="pendiente">Pendientes</option>
    </select>
    <p id="pinta-estadisticas"><button id="estadisticas">Estadisticas</button></p>
    <button id="btn-favoritos">⭐ Mis favoritos</button>
    <hr>
    <div id="cartas"></div>
  </main>
</body>
</html>
`;


const cohetes: Cohete[] = await recibeCohetes();


let cohetesActuales: Cohete[] = [...cohetes];


let favoritos: string[] = JSON.parse(localStorage.getItem('favoritos') ?? '[]') || [];
let mostrandoFavoritos: boolean = false;


const cartas = document.getElementById('cartas') as HTMLElement;
const buscaCohete = document.getElementById('busca-cohete') as HTMLInputElement;
const filtroEstado = document.getElementById('filtro-estado') as HTMLSelectElement;
const pintaEstadisticas = document.getElementById('pinta-estadisticas') as HTMLElement;
const estadisticas = document.getElementById('estadisticas') as HTMLButtonElement;
const btnFavoritos = document.getElementById('btn-favoritos') as HTMLButtonElement;


estadisticas.addEventListener('click', () => {
  const estadistica = cohetes.reduce(
    (acc, cohete) => {
      acc.total++;
      if (cohete.success) {
        acc.exitos++;
      } else {
        acc.fallidos++;
      }
      return acc;
    },
    { total: 0, exitos: 0, fallidos: 0 }
  );

  const porcentajeExito =
    estadistica.total > 0
      ? ((estadistica.exitos / estadistica.total) * 100).toFixed(1)
      : '0';

  pintaEstadisticas.innerHTML = `Porcentaje de exito: ${porcentajeExito}%, total: ${estadistica.total} | Nº exitos: ${estadistica.exitos} | Nº fallos: ${estadistica.fallidos}`;
});


filtroEstado.addEventListener('change', (event: Event) => {
  const estado = (event.target as HTMLSelectElement).value;

  if (estado === 'todos') {
    cohetesActuales = cohetes;
  } else if (estado === 'exitoso') {
    cohetesActuales = cohetes.filter((cohete) => cohete.success === true);
  } else if (estado === 'fallido') {
    cohetesActuales = cohetes.filter((cohete) => cohete.success === false);
  } else if (estado === 'pendiente') {
    cohetesActuales = cohetes.filter((cohete) => cohete.success == null);
  }

  actualizarVista();
});


buscaCohete.addEventListener('input', () => {
  const text = buscaCohete.value.trim().toLowerCase();
  cohetesActuales = cohetes.filter((cohete) =>
    cohete.name.toLowerCase().trim().includes(text)
  );

  actualizarVista();
});


function pintarCohetes(listaCohetes: Cohete[]): void {
  if (listaCohetes.length === 0) {
    cartas.innerHTML = `<p>Lo siento pero la peticion no trae nada</p>`;
    return;
  }

  cartas.innerHTML = listaCohetes
    .map((cohete) => {
      const esFavorito = favoritos.includes(cohete.name);
      const claseFavorito = esFavorito ? 'activo' : '';
      const textoEstrella = esFavorito ? '⭐' : '☆';

      return `
      <div class="contenedor">
        <div class="card-content">
            <div class="card-header">
                <h3 class="launch-name">${cohete.name}</h3>
                <span class="badge ${cohete.status ?? ''}">${cohete.status ?? ''}</span>
                <span class="badge ${String(cohete.success ?? 'pendiente')}">${cohete.success ?? 'Pendiente'}</span>
                <button class="btn-fav ${claseFavorito}" data-id="${cohete.name}">
                  ${textoEstrella} Favorito
                </button>
            </div>
            <p class="launch-date">📅 ${cohete.date_utc}</p>
        </div>
      </div>`;
    })
    .join('');
}


function actualizarVista(): void {
  if (mostrandoFavoritos) {
    const filtradosFavoritos = cohetesActuales.filter((c) => favoritos.includes(c.name));
    pintarCohetes(filtradosFavoritos);
  } else {
    pintarCohetes(cohetesActuales);
  }
}


cartas.addEventListener('click', (event: MouseEvent) => {
  const target = event.target as HTMLElement | null;
  const btnFav = target?.closest<HTMLButtonElement>('.btn-fav');
  if (!btnFav) return;

  const idCohete = btnFav.getAttribute('data-id');
  if (!idCohete) return;

  if (favoritos.includes(idCohete)) {
    favoritos = favoritos.filter((id) => id !== idCohete);
  } else {
    favoritos.push(idCohete);
  }

  localStorage.setItem('favoritos', JSON.stringify(favoritos));
  actualizarVista();
});


btnFavoritos.addEventListener('click', () => {
  mostrandoFavoritos = !mostrandoFavoritos;

  if (mostrandoFavoritos) {
    btnFavoritos.textContent = '🏠 Ver todos';
  } else {
    btnFavoritos.textContent = '⭐ Mis favoritos';
  }

  actualizarVista();
});


pintarCohetes(cohetes);